
#include "user.h"
#include "timer.h"
#include "RTC.h"
u8 KEY[6]={0xff,0xff,0xff,0xff,0xff,0xff};//��������
extern list_poin seq_carpack; 
  
extern int blue ;
extern int add;
extern int start_up;
extern int count;
extern int extern_fang;
int quan =0;

union test bkp_in;


int read_IC_type( unsigned char *CT, unsigned char *SN)
{
	unsigned char status;
	
	return 0;
}

int read_IC_information(unsigned char *CT ,unsigned char *SN , u8  (*temp)[16])
{
	unsigned char status;
	
	status = PcdRequest(PICC_REQIDL ,CT);
	/*����ײ*/
	if(status == MI_OK)
		status = PcdAnticoll(SN);
	//ѡ����Ƭ
	if(status == MI_OK)
		status = PcdSelect(SN);
	if(status == MI_OK)
	{
		printf("\r\n");
		printf("��Ƭ����===%x%x\r\n",CT[0],CT[1]);
		printf("����=======%x,%x\r\n",SN[0],SN[1]);
		printf("\r\n");
	}	
	
	
	if(status == MI_OK)
		status =PcdAuthState(PICC_AUTHENT1B, 12, KEY, SN);	
	if(status == MI_OK)
	{	
		status = PcdRead(12,temp[0]);
		status = PcdRead(13,temp[1]);	
	}
	else
	{
		return 0;
	}
		
	
	if(status == MI_OK)
	{	
		printf("��� == %s\r\n",temp[0]);
		printf("ʱ�� == %s\r\n",temp[1]);
		printf("\r\n");
		return 1;
	}	
	
	return 0;
	
	
}


int bluetooth_add(int add1)
{
	unsigned char CT[2];// ����
	unsigned char SN[4]; //����
	u8 temp[16];
	int balance =0;
	char status = 0;
	status = PcdRequest(PICC_REQIDL ,CT);
	/*����ײ*/
	if(status == MI_OK)
		status = PcdAnticoll(SN);
	//ѡ����Ƭ
	if(status == MI_OK)
		status = PcdSelect(SN);
		//����Ϣ
	status = PcdAuthState(PICC_AUTHENT1B, 12, KEY, SN);
	if(status == MI_OK)
	{
		printf("��֤ͨ��");
	}
	//��ȡ���
	status = PcdRead(12,temp);
	if(status == MI_OK && !strcmp(temp,"\0"))
	{
		sprintf(temp,"%d",add);
		status = PcdWrite(12,temp);
		status = PcdWrite(13,"000000000");
		printf(" 89___�������===%s\r\n",temp); /////
		LCD_ShowString(50,270,300,24,24,"balance is....");
		LCD_ShowString(50,310,300,24,24,temp);
		delay_s(3);
		blue = 0;
		add = 0;
		return 0;
	}
	if(status == MI_OK)
	{
		printf(" ��ֵǰ���====%s\r\n",temp);  ////
		sscanf((char *)temp,"%d",&balance);
		balance = balance + add1;
		
		sprintf((char*)temp,"%d",balance);
		status = PcdWrite(12,temp);
		if(status == MI_OK)
		{
			printf("д����ȷ");
		}	
		printf(" 106__�������===%s\r\n",temp); /////
		printf("��Ǯ��ɡ\\r\n");
		LCD_ShowString(50,310,300,24,24,"balance is....");
		LCD_ShowString(50,330,300,24,24,temp);
		LCD_ShowString(50,370,200,24,24,"OK!!!!");
		delay_s(3);
		show_car_image(seq_carpack);
		PcdHalt();
		blue = 0;
		add = 0;
	}
		return 0;
}



int Analysis_IC(u8 (*temp)[16],u32 time_min,unsigned char *SN)
{
	char status;
	int circle = 0 ;
	int balance = 0;
	u8 change_time[16];
	u8 time_lcd[24];
	u32 time_mid;
	sscanf((char*)temp[0],"%d",&balance);
	sscanf((char*)temp[1],"%d",&time_mid);
	//�ų���ʱ��ˢ��
	if(temp[1][8] == '0' )
	{
		//
		LCD_Clear(WHITE);
		LCD_ShowString(10,30,300,24,24,"PARKING_CAR");
		LCD_ShowString(100,180,300,24,24,"Reminder");
		//
		printf("\r\n�ų���ʱ��ˢ��\r\n");
		//�鿴����Ƿ���㣬������λ�ò�����
		if( balance < 5)
		{
			printf("���㣡\r\n");
			LCD_ShowString(50,270,300,24,24,"Sorry,your credit is running low");

			delay_s(3);
			return 0;
		}
		//�鿴��λ�Ƿ�������������λ�ò���
		if(IS_NULL_parkcar()>6)
		{
			printf("��λ����/r/n");
			return 0;
		}
		//�ų� λ�ò���
		circle = Park_car(SN);	
		sprintf((char *)change_time,"%d%d",time_min,1);
		status = PcdWrite(13,change_time);	
		if(status != MI_OK)
		{
			printf("�ų�д����Ϣ������\r\n");
			LCD_ShowString(100,330,200,24,24,"error");
			return 0;
		}
			
	
		LCD_ShowString(50,270,300,24,24,"Parking in the car....");
		LCD_ShowString(50,300,200,24,24,"balance is ");
		LCD_ShowxNum(200,300,balance,3,24,1);
		LCD_ShowString(50,330,30,24,24,"time:");
		RTC_Get_time();
		sprintf(time_lcd,"%d-%d-%d %d:%d:%d\n",calendar.w_year,calendar.w_month,calendar.w_date,calendar.hour,calendar.min,calendar.sec);
		LCD_ShowString(100,330,200,24,24,time_lcd);
		
		delay_s(3);
		
		

	}
	//ȡ����ʱ��ˢ��
	else if(temp[1][8] == '1' )
	{
		int t;
		//
		LCD_Clear(WHITE);
		LCD_ShowString(10,30,300,24,24,"GETTING_CAR");
		LCD_ShowString(100,180,300,24,24,"Reminder");
		printf("\r\nȡ����ʱ��ˢ��\r\n");
		//�Ƿ��иó�
		t = lookup_car(SN);
		if(t == 0)
		{
			printf("û�д˳�\r\n");
			status = PcdWrite(13,"000000000");
			return 0;
		}	
		//����ͣ��ʱ�� ��������۷���Ϣ 
		balance = collect_fees(temp[1],time_min,balance);
		LCD_ShowString(50,400,100,24,24,"total:");
		
		//���㣬λ�ò���
		if(balance < 0)
		{
			LCD_ShowString(50,270,300,24,24,"Sorry,your credit is running low");
			delay_s(3);
			printf("����,�뵽��������ֵ\r\n");
			return 0;
		}		
		//ȡ�� λ�ò���
		circle = Get_car(t);	
		//д��۷Ѻ��ֵ
		sprintf(temp[3],"%d",balance);
		PcdWrite(12,temp[3]);
		printf("ȡ��������====%d",balance);
		status = PcdWrite(13,"000000000");
		if(status != MI_OK)
			printf("ȡ��д����Ϣ����\r\n");
		
		LCD_ShowString(50,270,300,24,24,"Picking up your car....");
		LCD_ShowString(50,300,200,24,24,"balance is ");
		LCD_ShowxNum(200,300,balance,3,24,1);
		LCD_ShowString(50,330,50,24,24,"time:");
	
		

		time_mid = time_mid/10;
		
		RTC_Get_time_1(time_mid);
		sprintf(time_lcd,"%d-%d-%d %d:%d:%d\n",calendar.w_year,calendar.w_month,calendar.w_date,calendar.hour,calendar.min,calendar.sec);
		LCD_ShowString(100,330,200,24,24,time_lcd);
		
		RTC_Get_time();
		sprintf(time_lcd,"%d-%d-%d %d:%d:%d\n",calendar.w_year,calendar.w_month,calendar.w_date,calendar.hour,calendar.min,calendar.sec);
		LCD_ShowString(100,380,200,24,24,time_lcd);
		
		delay_s(3);
		
	}
	else
	{
		status = PcdWrite(12,"0");
		status = PcdWrite(13,"000000000");
		//
		LCD_Clear(WHITE);
		LCD_ShowString(100,180,300,24,24,"Reminder");
		LCD_ShowString(50,270,300,24,24,"New user !,Please recharge....");
		//LCD_ShowString(50,270,300,16,16,"Please recharge....");
		delay_s(3);
		//
		printf("���û���\r\n ����г�ֵ�� ��ˢ����\r\n");

		if(status  == MI_OK)
			printf("sad");
	}
	return circle;
}

char zhuan_num(int i)
{

	if( i == 0)
		return 0;
	else if(i > 0) 
		Clockwise
	else
		Anti_clockwise
	
	i = abs(i);
	i = i*107;
	quan = i/(1.8/micro)*2 + 2;
	printf("quan === %d\r\n",quan);
	UNLOCK;
	TIM_Cmd(TIM3,ENABLE);
	//TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);
	return 0;
}

 
// PB5 ---�� ����   PB7 ---  DIAN   PB8   ---> �DDIR   
//PF3 --- >>   ����      PF1 ----  ���      PF0   dir
void CS_Init()
{
	GPIO_InitTypeDef GPIO_InitSture;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF,ENABLE);
	GPIO_InitSture.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitSture.GPIO_Pin=GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_3 ;
	GPIO_InitSture.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOF,&GPIO_InitSture);
	LOCK;
}


//****************************************************************************************************************//
//****************************************************************************************************************//
//****************************************************************************************************************//



int IS_NULL_parkcar(void)
{
	int i;
	list_poin p;
	p = seq_carpack;
	for(i = 0; i < 6;i++)
	{
		if(p->seat == No_car)
			break;
		p = p->next;
		if(i==5)
			return 7;
	}
}

int lookup_car(unsigned char *SN)
{
	int i;
	list_poin p;
	p = seq_carpack;
	for(i = 0; i < 6;i++)
	{
		if(p->card_num[0]==SN[0] && p->card_num[1]==SN[1])
		{
			printf("�ҵ� ���� \r\n");
			return p->num;
		}
		p = p->next;
	}
	return 0;
}

int Get_car(int t)
{
	int i;
	int temp;
	//�ҵ���ǰλ��
	for(i = 0; i < 6;i++)
	{
		if(seq_carpack->current==1)
		{
			seq_carpack->current = 0;
			temp = seq_carpack->num;
			break;
		}
		seq_carpack = seq_carpack->next;
	}
	//
	i = temp - t;
	if(i == 5 ) 
		i = -1;
	else if(i == -5)
		i = 1;
	else if(i == 4)
		i = -2;
	else if(i == -4)
		i = 2;
   
	temp = i;
//************************************************************************************************
	if(i == 0)
	{	
		memset(seq_carpack->card_num,0,4);
		seq_carpack->current = 1;
		seq_carpack->seat = 0;
	}
	//˳
	else if(i>0)
	{
		for(; i>0 ;i--) 
		{
			printf("��ʱ��תһ�� \r\n");
			seq_carpack = seq_carpack->prev;
		}
		memset(seq_carpack->card_num,0,4);
		seq_carpack->current = 1;
		seq_carpack->seat = 0;
	}
	//��
	else 
	{
		i=abs(i);
		for(; i>0 ;i--)
		{
			printf("˳ʱ��תһ��  \r\n");
			seq_carpack = seq_carpack->next;
		}
		memset(seq_carpack->card_num,0,4);
		seq_carpack->current = 1;
		seq_carpack->seat = 0;
	}
	
	return temp;
}


int Park_car(unsigned char *SN_TOW)
{
	int i;
	list_poin p;
	int temp ;
	
	//��ȡ�ճ�λ��Ϣ
	p = seq_carpack;
	//�ҵ���ǰλ��
	for(i = 0; i < 6;i++)
	{
		if(p->current==1)
		{
			seq_carpack->current = 0;
			break;
		}
		p = p->next;
	}
	//�����ֵ
	if(p->seat == No_car)
		i = 0;
	else if(p->next->seat==No_car)
		i = p->num - p->next->num;
	else if(p->prev->seat==No_car)	
		i = p->num - p->prev->num;
	else if(p->next->next->seat==No_car)	
		i = p->num - p->next->next->num;
	else if(p->prev->prev->seat==No_car)	
		i = p->num - p->prev->prev->num;
	else
		i = 3;
	
	if(i == 5 ) 
		i = -1;
	else if(i == -5)
		i = 1;
	else if(i == 4)
		i = -2;
	else if(i == -4)
		i = 2;
	
	temp = i;
//************************************************************************************************
	if(i == 0)
	{	
		strcpy((char*)seq_carpack->card_num,(char*)SN_TOW);
		seq_carpack->current = 1;
		seq_carpack->seat = 1;
	}
	//˳
	else if(i>0)
	{
		for(; i>0 ;i--)
		{
			printf("��ʱ��תһ�� \r\n");
			seq_carpack = seq_carpack->prev;
		}
		strcpy((char*)seq_carpack->card_num,(char*)SN_TOW);
		seq_carpack->current = 1;
		seq_carpack->seat = 1;
	}
	//��
	else 
	{
		i=abs(i);
		for(; i>0 ;i--)
		{
			printf("˳ʱ��תһ��  \r\n");
			seq_carpack = seq_carpack->next;
		}
		strcpy((char*)seq_carpack->card_num,(char*)SN_TOW);
		seq_carpack->current = 1;
		seq_carpack->seat = 1;
	}

	return temp;
}



int collect_fees(u8 temp[], u32 time_min,int balance)
{
	int  time_mid , time_end;
	
	sscanf((char*)temp,"%d",&time_mid);
	
	time_mid = time_min -time_mid/10;	
	time_end = time_mid/60; 
	//�������ڲ���Ǯ
	if(time_mid%60 > 2)
		time_end++;
	printf("Сʱ��=== %d\r\n", time_end);	
				
	balance = balance - time_end*5 ;
	printf("һ�����ѽ�%d\r\n\r\n",time_end*5);
	LCD_ShowxNum(200,400,5,3,24,1);	
	
	return balance;
}

void delay_s(int i)
{
	int j=0;
	for(; j<=i ; j++)
	 delay_ms(1000);
}

void PWR_PVD_Init(void) 
{   
    NVIC_InitTypeDef NVIC_InitStructure;
    EXTI_InitTypeDef EXTI_InitStructure;
     
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);//ʹ��pwr
 
    NVIC_InitStructure.NVIC_IRQChannel = PVD_IRQn;           //PVD�ⲿ�ж�ͨ��
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;//1
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;       //0
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;          //ʹ���ⲿ�ж�
    NVIC_Init(&NVIC_InitStructure);
     
    EXTI_StructInit(&EXTI_InitStructure);
    EXTI_InitStructure.EXTI_Line = EXTI_Line16;             //PVD�ж���16
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;     //�ж�ģʽ
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;  //���ڷ�ֵ�����ж�
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;               //ʹ���ж���
    EXTI_Init(&EXTI_InitStructure);                         //��ʼ��
     
    PWR_PVDLevelConfig(PWR_PVDLevel_2V6);// �趨��ֵ
    PWR_PVDCmd(ENABLE);//ʹ��PVD     
}
 
void PVD_IRQHandler(void)
{ 
    EXTI_ClearITPendingBit(EXTI_Line16);//���ж�
    
		bkp_in.a = quan - count;
		BKP_WriteBackupRegister(BKP_DR2,bkp_in.b[0]); 
		BKP_WriteBackupRegister(BKP_DR3,bkp_in.b[1]); 
		BKP_WriteBackupRegister(BKP_DR4,bkp_in.b[2]); 
		BKP_WriteBackupRegister(BKP_DR5,bkp_in.b[3]); 		
		BKP_WriteBackupRegister(BKP_DR6,extern_fang); 
}


