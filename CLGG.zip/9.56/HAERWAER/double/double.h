#ifndef __DOUBLE_SEQ__
#define __DOUBLE_SEQ__

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "stm32f10x.h"


#define No_car 0
#define Yes_car 1

//商品节点链表
typedef struct parkcar
{
	unsigned char card_num[2];
	int current;
	int seat;
	int num;
	struct parkcar *prev; 
	struct parkcar *next; 
	
}listnode, *list_poin;

u8 BKP_Write_seq(list_poin head);

list_poin init_seq(void);
//list_poin creat_head_node();

list_poin creat_node(int i, int cur);

int link_node(list_poin head,list_poin temp);

int show_zheng(list_poin head);

u8 BKP_Init(void);

u8 BKP_Write(list_poin head , int i);
#endif
