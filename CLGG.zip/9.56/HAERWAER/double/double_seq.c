
#include "double.h"

u8 BKP_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_BKP|RCC_APB1Periph_PWR,ENABLE);
	PWR_BackupAccessCmd(ENABLE);
	return 0;
}
list_poin creat_node(int i, int cur)
{
	list_poin new_node = malloc(sizeof(listnode));
	
//	new_node->current = cur;
//	new_node->seat = 0 ;
//	new_node->num = i;
//
	
	switch(i)
	{
		case 1:
						new_node->current = BKP_ReadBackupRegister(BKP_DR12);
						new_node->seat = BKP_ReadBackupRegister(BKP_DR13);
						new_node->num = BKP_ReadBackupRegister(BKP_DR14);
						new_node->card_num[0] = BKP_ReadBackupRegister(BKP_DR15);
						new_node->card_num[1] = BKP_ReadBackupRegister(BKP_DR16);
						break;
		case 2:
						new_node->current = BKP_ReadBackupRegister(BKP_DR17);
						new_node->seat = BKP_ReadBackupRegister(BKP_DR18);
						new_node->num = BKP_ReadBackupRegister(BKP_DR19);
						new_node->card_num[0] = BKP_ReadBackupRegister(BKP_DR20);
						new_node->card_num[1] = BKP_ReadBackupRegister(BKP_DR21);
						break;
		case 3:
						new_node->current = BKP_ReadBackupRegister(BKP_DR22);
						new_node->seat = BKP_ReadBackupRegister(BKP_DR23);
						new_node->num = BKP_ReadBackupRegister(BKP_DR24);
						new_node->card_num[0] = BKP_ReadBackupRegister(BKP_DR25);
						new_node->card_num[1] = BKP_ReadBackupRegister(BKP_DR26);
						break;
		case 4:
						new_node->current = BKP_ReadBackupRegister(BKP_DR27);
						new_node->seat = BKP_ReadBackupRegister(BKP_DR28);
						new_node->num = BKP_ReadBackupRegister(BKP_DR29);
						new_node->card_num[0] = BKP_ReadBackupRegister(BKP_DR30);
						new_node->card_num[1] = BKP_ReadBackupRegister(BKP_DR31);
						break;
		case 5:
						new_node->current = BKP_ReadBackupRegister(BKP_DR32);
						new_node->seat = BKP_ReadBackupRegister(BKP_DR33);
						new_node->num = BKP_ReadBackupRegister(BKP_DR34);
						new_node->card_num[0] = BKP_ReadBackupRegister(BKP_DR35);
						new_node->card_num[1] = BKP_ReadBackupRegister(BKP_DR36);
						break;
		case 6:
						new_node->current = BKP_ReadBackupRegister(BKP_DR37);
						new_node->seat = BKP_ReadBackupRegister(BKP_DR38);
						new_node->num = BKP_ReadBackupRegister(BKP_DR39);
						new_node->card_num[0] = BKP_ReadBackupRegister(BKP_DR40);
						new_node->card_num[1] = BKP_ReadBackupRegister(BKP_DR41);
						break;
	}
		if(!new_node)
	{
		printf("??????!\n");
		return NULL;
	} 

	new_node->next = new_node->prev = new_node;
	return new_node;
}


int link_node(list_poin head,list_poin temp)
{
	list_poin p = head;
	while(p->next != head)
	{
		p = p->next;
	}
	
	temp->prev = p;
	temp->next =p->next;
	temp->next->prev = temp;
	p->next = temp;

	return 0;
}

int show_zheng(list_poin head)
{
	list_poin p;
	p = head;
	printf("num==%d		car-->%d		current-->%d		SN-->%x%x\r\n",p->num,p->seat,p->current,p->card_num[0],p->card_num[1]);
	while(p->next != head)
	{
		p = p->next;
		printf("num==%d		car-->%d		current-->%d		SN-->%x%x\r\n",p->num,p->seat,p->current,p->card_num[0],p->card_num[1]);
	}
	return 0;
}

list_poin init_seq(void)
{
	list_poin head;
	list_poin temp;
	int i;
	head = creat_node(1,1);

	for(i = 2 ; i<7 ;i++)
	{
		temp = creat_node(i,0);
		link_node(head,temp); 
	}
	
	return head;
}
u8 BKP_Write_seq(list_poin head)
{
	list_poin p;
	int i;
	p = head;
	
	for(i=1;i<7;i++)
	{
		BKP_Write(p,i);
		p = p->next;
	}
	
	return 0;
}
u8 BKP_Write(list_poin head , int i)
{
	list_poin p;
	char temp1,temp2;
	p = head;
	switch(i)
	{
		case 1:
						BKP_WriteBackupRegister(BKP_DR12,p->current);
						BKP_WriteBackupRegister(BKP_DR13,p->seat);
						BKP_WriteBackupRegister(BKP_DR14,p->num);
						BKP_WriteBackupRegister(BKP_DR15,p->card_num[0]);
						BKP_WriteBackupRegister(BKP_DR16,p->card_num[1]);
						break;
		case 2:
						BKP_WriteBackupRegister(BKP_DR17,p->current);
						BKP_WriteBackupRegister(BKP_DR18,p->seat);
						BKP_WriteBackupRegister(BKP_DR19,p->num);
						BKP_WriteBackupRegister(BKP_DR20,p->card_num[0]);
						BKP_WriteBackupRegister(BKP_DR21,p->card_num[1]);
						break;
		case 3:
						BKP_WriteBackupRegister(BKP_DR22,p->current);
						BKP_WriteBackupRegister(BKP_DR23,p->seat);
						BKP_WriteBackupRegister(BKP_DR24,p->num);
						BKP_WriteBackupRegister(BKP_DR25,p->card_num[0]);
						BKP_WriteBackupRegister(BKP_DR26,p->card_num[1]);
						break;
		case 4:
						BKP_WriteBackupRegister(BKP_DR27,p->current);
						BKP_WriteBackupRegister(BKP_DR28,p->seat);
						BKP_WriteBackupRegister(BKP_DR29,p->num);
						BKP_WriteBackupRegister(BKP_DR30,p->card_num[0]);
						BKP_WriteBackupRegister(BKP_DR31,p->card_num[1]);
						break;
		case 5:
						BKP_WriteBackupRegister(BKP_DR32,p->current);
						BKP_WriteBackupRegister(BKP_DR33,p->seat);
						BKP_WriteBackupRegister(BKP_DR34,p->num);
						BKP_WriteBackupRegister(BKP_DR35,p->card_num[0]);
						BKP_WriteBackupRegister(BKP_DR36,p->card_num[1]);
						break;
		case 6:
						BKP_WriteBackupRegister(BKP_DR37,p->current);
						BKP_WriteBackupRegister(BKP_DR38,p->seat);
						BKP_WriteBackupRegister(BKP_DR39,p->num);
						BKP_WriteBackupRegister(BKP_DR40,p->card_num[0]);
						BKP_WriteBackupRegister(BKP_DR41,p->card_num[1]);
						break;
	}		
	return 0;
}
